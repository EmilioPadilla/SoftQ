<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoDonante extends Model
{
     //assigning db table model is associated with
     protected $table = 'tipo_donante';
     //use HasFactory;
}
