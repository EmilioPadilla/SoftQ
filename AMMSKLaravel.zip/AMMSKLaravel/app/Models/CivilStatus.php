<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CivilStatus extends Model
{
    //assigning db table model is associated with
    protected $table = 'civil_status';

    public $timestamps = false;

}
