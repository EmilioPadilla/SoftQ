<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vacations extends Model
{
    //assigning db table model is associated with
    protected $table = 'vacations';
    public $timestamps = false;
}
